package com.example.views;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Configuration;
import com.vaadin.addon.charts.model.DataSeries;
import com.vaadin.addon.charts.model.DataSeriesItem;
import com.vaadin.addon.charts.model.PlotOptionsLine;
import com.vaadin.addon.charts.model.PlotOptionsPie;
import com.vaadin.addon.charts.model.style.SolidColor;
import com.vaadin.navigator.View;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.VerticalLayout;

public class SOWAView extends VerticalLayout implements View{
	public static final String NAME="SOWA";
	public SOWAView()
	{
		setMargin(true);		
		   
		   HorizontalLayout line01 = new HorizontalLayout();
		   HorizontalLayout line02 = new HorizontalLayout();
		   
		   line01.addComponent(getPieChart());
		   line02.addComponent(getLineChart());
		   addComponents(line01,line02);
	}
	private Chart getPieChart()
	{
		Chart chart = new Chart(ChartType.PIE);
		chart.setWidth("300px");
		chart.setHeight("300px");		
		Configuration conf = chart.getConfiguration();
		conf.setTitle("Pie Chart");
		PlotOptionsPie options = new PlotOptionsPie();
		options.setInnerSize("50px");
		options.setSize("75%");
		options.setCenter("50%", "50%");
		conf.setPlotOptions(options);
		DataSeries series = new DataSeries();
		series.add(new DataSeriesItem("35%", 35));
		series.add(new DataSeriesItem("40%", 40));
		DataSeriesItem s25 = new DataSeriesItem("25%", 25);
		s25.setSliced(true);
		series.add(s25);
		conf.addSeries(series);		
		
		return chart;
	}
	private Chart getLineChart()
	{
		   Chart chart = new Chart();
		   chart.setWidth("300px");
		   chart.setHeight("300px");
		   Configuration conf = chart.getConfiguration();
		   conf.getChart().setType(ChartType.LINE);
		   conf.setTitle("Line Chart");

		   DataSeries serie1 = new DataSeries("SERIE 1");
		   serie1.add(new DataSeriesItem(0,0));
		   serie1.add(new DataSeriesItem(1,1));
		   serie1.add(new DataSeriesItem(2,2));
		   serie1.add(new DataSeriesItem(3,3));
		   serie1.add(new DataSeriesItem(4,4));
		   conf.addSeries(serie1);
		   PlotOptionsLine serie1Opts = new PlotOptionsLine();
		   serie1Opts.setColor(SolidColor.BLUE);
		   serie1.setPlotOptions(serie1Opts);

		   DataSeries serie2 = new DataSeries("SERIE 2");
		   serie2.add(new DataSeriesItem(0,2));
		   serie2.add(new DataSeriesItem(1,2));
		   serie2.add(new DataSeriesItem(2,3));
		   serie2.add(new DataSeriesItem(3,4));
		   serie2.add(new DataSeriesItem(4,5));
		   conf.addSeries(serie2);
		   PlotOptionsLine serie2Opts = new PlotOptionsLine();
		   serie2Opts.setColor(SolidColor.RED);
		   serie2.setPlotOptions(serie2Opts);
		   
		   return chart;
	}

}
